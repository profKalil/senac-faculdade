package com.senac;

import java.util.ArrayList;

public class AcervoLivros{
    private ArrayList<Livro> listaLivros;

    public AcervoLivros(ArrayList<Livro> livros) {
        this.listaLivros = livros;
    }

    public void adicionarLivro(Livro livro) {
        listaLivros.add(livro);
        System.out.println("Livro adicionado ao acervo: " + livro.getTitulo());
    }

    public void exibirAcervo() {
        System.out.println("Acervo de Livros:");
        for (Livro livro : listaLivros) {
            System.out.println("- " + livro.getTitulo() + " do autor:  " +  livro.getAutor());
        }
        // for (int x = 0; x < listaLivros.size(); x++;) {
        //      Livro livro = listaLivros.get(x);
        // }
    }
}
