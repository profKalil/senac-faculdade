package com.senac;

import java.util.ArrayList;

public class Main {
    public static void main (String[] args) {
        // instanciar
        ArrayList<Livro> livros = new ArrayList<>();
        AcervoLivros acervo = new AcervoLivros(livros);

        // criar livros
        Livro livro_kalil = new Livro("Kalil", "Aula de Java");

        // adicionar livros à lista
        acervo.adicionarLivro(livro_kalil);

        // exibir livros
        acervo.exibirAcervo();
    }
}
