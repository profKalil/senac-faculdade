import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame janela = new JFrame("Apresentação");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Box caixa = Box.createVerticalBox();

        // Nome
        JLabel lblNome = new JLabel("Nome: ");
        JTextField txtNome = new JTextField(20);

        // Sobrenome
        JLabel lblSobrenome = new JLabel("Sobrenome: ");
        JTextField txtSobrenome = new JTextField(20);

        JButton btnOK = new JButton("OK");

        btnOK.addActionListener(e -> {
            String nome = txtNome.getText();
            String sobrenome = txtSobrenome.getText();
            String nomeCompleto = nome + " " + sobrenome;

            JOptionPane.showMessageDialog(null, "Bem-vindo: " + nomeCompleto);
        } );

        caixa.add (lblNome);
        caixa.add (txtNome);
        caixa.add (lblSobrenome);
        caixa.add (txtSobrenome);
        caixa.add (btnOK);

        janela.add(caixa);

        janela.setSize(300, 150);
        janela.setVisible(true);
    }
}