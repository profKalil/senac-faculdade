import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class AgendaView {
  private JTextField txtNome, txtSnome, txtTel;
  private JButton btnOK;
  public AgendaView () {
    JFrame janela = new JFrame ("Agenda");
    janela.setSize (300, 300);
    janela.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
    JPanel painel = new JPanel ();
    JLabel lblNome = new JLabel ("Nome: ");
    txtNome = new JTextField (20);
    JLabel lblSnome = new JLabel ("Sobrenome: ");
    txtSnome = new JTextField (20);
    JLabel lblTel = new JLabel ("Telefone: ");
    txtTel = new JTextField (20);
    btnOK = new JButton ("OK");

    painel.add(lblNome);
    painel.add(txtNome);
    painel.add(lblSnome);
    painel.add(txtSnome);
    painel.add(lblTel);
    painel.add(txtTel);
    painel.add(btnOK);

    janela.add(painel);
    janela.setVisible(true);
  }

  public String getTxtNome () {
    return txtNome.getText();
  }

  public String getTxtSnome () {
    return txtSnome.getText();
  }

  public String getTxtTel () {
    return txtTel.getText();
  }
  
  public void setBtnOK (ActionListener acao) {
    btnOK.addActionListener(acao);
  }
  
}


