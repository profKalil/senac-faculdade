
public class Main {
    public static void main(String[] args) {
        NomeModel model = new NomeModel();
        NomeView view = new NomeView();
        NomeController controller = new NomeController(model, view);
    }
}
