import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class NomeController {
    private NomeModel model;
    private NomeView view;

    public NomeController(NomeModel model, NomeView view) {
        this.model = model;
        this.view = view;
        view.setButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateModelFromView();
                displayNome();
            }
        });
    }

    private void updateModelFromView() {
        model.setNome(view.getNome());
        model.setSnome(view.getSnome());
    }

    private void displayNome() {
        JOptionPane.showMessageDialog(null, "Seu nome completo é: " + model.getNome());
    }
}
