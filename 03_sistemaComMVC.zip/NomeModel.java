class NomeModel {
    private String nome;
    private String snome;


    public void setNome(String nome) {
        this.nome = nome;
    }


    public void setSnome(String snome) {
        this.snome = snome;
    }

    public String getNome() {
        return nome + " " + snome;
    }
}
