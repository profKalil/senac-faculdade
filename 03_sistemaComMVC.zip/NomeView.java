import javax.swing.*;
import java.awt.event.ActionListener;

class NomeView {
    private JTextField txtNome;
    private JTextField txtSnome;
    private JButton btnOk;

    public NomeView() {
        JFrame frame = new JFrame("Nome Completo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel caixa = new JPanel();

        JLabel lblNome = new JLabel("Nome: ");
        txtNome = new JTextField(20);

        JLabel lblSnome = new JLabel("Sobrenome: ");
        txtSnome = new JTextField(20);

        btnOk = new JButton("Mostrar Nome Completo");

        caixa.add(lblNome);
        caixa.add(txtNome);
        caixa.add(lblSnome);
        caixa.add(txtSnome);
        caixa.add(btnOk);

        frame.add(caixa);

        frame.setSize(300, 200);
        frame.setVisible(true);
    }

    public String getNome() {
        return txtNome.getText();
    }

    public String getSnome() {
        return txtSnome.getText();
    }

    public void setButtonListener(ActionListener listener) {
        btnOk.addActionListener(listener);
    }
}