import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

class AgendaController {
    private AgendaModel model;
    private AgendaView view;

    public AgendaController () {
        this.model = new AgendaModel();
        this.view = new AgendaView();

        view.setBtnOK(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizaView();
                showAgenda();
            }
        });
    }
    private void atualizaView() {
        model.setNome(view.getTxtNome());
        model.setSnome(view.getTxtSnome());
        model.setTel(view.getTxtTel());
    }
    private void showAgenda() {
        JOptionPane.showMessageDialog(null, " Cadastrado com sucesso ! " + model.getCompleto());
    }
}
