class AgendaModel {
    private String nome, snome, tel;
    public void setNome (String nome) {
        this.nome = nome;
    }
    public void setSnome (String snome) {
        this.snome = snome;
    }
    public void setTel (String tel) {
        this.tel = tel;
    }
    public String getCompleto () {
        return "\n\n  > " + nome + " " + snome + " \nTel.:" + tel;
    }
}