import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CardapioController {
    private CardapioModel model;
    private CardapioView view;

    public CardapioController() {
        this.model = new CardapioModel();
        this.view = new CardapioView();

        view.setBtnOK(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codigo = view.getText();
                atualizaView(codigo);
            }
        });
    }

    private void atualizaView(String codigo) {
        ArrayList<CardapioItens> itens = model.getItens();
        for (CardapioItens item : itens) {
            if (codigo.equals(item.getCodigo())) {

                JOptionPane.showMessageDialog(null, "\n" + item.getNome() + "\n > R$ " + item.getPreco());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Produto não encontrado!");
    }
}
