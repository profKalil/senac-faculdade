import java.util.ArrayList;

public class CardapioModel {
    private ArrayList <CardapioItens> itens;

    public CardapioModel() {
        this.itens = new ArrayList<>();
        itens.add(new CardapioItens("1001", "Cachorro-quente", 10.99));
        itens.add(new CardapioItens("1002", "X-salada", 15.99));
        itens.add(new CardapioItens("1003", "X-bacon", 19.99));
    }
    public ArrayList<CardapioItens> getItens() {
        return itens;
    }
}
