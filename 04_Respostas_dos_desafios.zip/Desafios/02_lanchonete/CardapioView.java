import javax.swing.*;
import java.awt.event.ActionListener;

public class CardapioView {
    private JFrame frame;
    private JLabel lblCodigo;
    private JTextField txtCodigo;
    private JButton btnOK;

    public CardapioView() {
        frame = new JFrame("Meu Restaurante");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        lblCodigo = new JLabel("Código : ");
        txtCodigo = new JTextField(10);
        btnOK = new JButton("OK");

        JPanel panel = new JPanel();
        panel.add(lblCodigo);
        panel.add(txtCodigo);
        panel.add(btnOK);

        frame.add(panel);
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public String getText() {
        return txtCodigo.getText();
    }
    public void setBtnOK(ActionListener listener) {
        btnOK.addActionListener(listener);
    }
}