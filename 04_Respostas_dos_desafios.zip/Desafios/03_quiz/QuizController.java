import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class QuizController {
    private QuizView view;
    private QuizModel model;
    private int contador=-0, indice=0;
    private String resposta;
    private QuizPergunta pergunta;

    public QuizController() {
        this.view = new QuizView();
        this.model = new QuizModel();

        view.setBtnOK(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizaView();
            }
        });
    }

    private void atualizaView() {

        if (indice < model.getPerguntas().size()) {
            pergunta = model.getPerguntas().get(indice);
            view.setLblPergunta(pergunta.getPergunta());
            resposta = view.getTxtResposta();

            if (resposta.equals(view.getTxtResposta())) {
                contador++;
            }
        }

        indice++;

        if (indice == model.getPerguntas().size()+1) {
            if (contador == model.getPerguntas().size()) {
                JOptionPane.showMessageDialog(null, "Você conseguiu!" );
                 System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "Que pena. Tente novamente." );
                System.exit(0);
            }
        }
    }
}