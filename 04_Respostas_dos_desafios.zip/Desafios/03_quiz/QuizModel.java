import java.util.ArrayList;

public class QuizModel {
    private ArrayList<QuizPergunta> perguntas;
    public QuizModel() {
        this.perguntas = new ArrayList<>();
        perguntas.add(new QuizPergunta("Qual é a capital do Brasil? A) São Paulo; B) Rio de Janeiro; C) Brasília", "C"));
        perguntas.add(new QuizPergunta("Quem inventou a lâmpada? A) Landel de Moura; B) Thomas Edson; C) Maquiavel", "B"));
        perguntas.add(new QuizPergunta("Quanto é o triplo do dobro de 6? A) 12; B) 36; C) 18", "B"));
        perguntas.add(new QuizPergunta("Que animal a seguir é um anfíbrio? A) Sapo; B) Coelho; C) Pato; ", "A"));
        perguntas.add(new QuizPergunta("Qual alternativa contém combustível que NÃO é fóssil? A) Gasolina; B) Etanol; C) Diesel", "B"));
    }
    public ArrayList<QuizPergunta> getPerguntas() {
        return perguntas;
    }
}