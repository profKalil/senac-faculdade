public class QuizPergunta {
    private String pergunta;
    private String gabarito;

    public QuizPergunta(String pergunta, String gabarito) {
        this.pergunta = pergunta;
        this.gabarito = gabarito;
    }

    public String getPergunta() {
        return pergunta;
    }

    public String getGabarito() {
        return gabarito;
    }
}
