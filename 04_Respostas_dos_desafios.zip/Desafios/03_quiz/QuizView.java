import javax.swing.*;
import java.awt.event.ActionListener;

public class QuizView {
    private JLabel lblPergunta, lblResposta;
    private JTextField txtResposta;
    private JButton btnOK;

    public QuizView () {
        JFrame janela = new JFrame ("Nosso Quiz");
        janela.setSize (1200, 200);
        janela.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        JPanel painel = new JPanel ();
        lblPergunta = new JLabel("Pressione OK para iniciar e responder!");
        lblResposta = new JLabel("> ");
        txtResposta = new JTextField(2);
        btnOK = new JButton("OK");

        painel.add(lblPergunta);
        painel.add(lblResposta);
        painel.add(txtResposta);
        painel.add(btnOK);

        janela.add(painel);
        janela.setVisible(true);
    }

    public String getTxtResposta () {
        return txtResposta.getText();
    }

    public void setLblPergunta(String pergunta) {
        lblPergunta.setText(pergunta);
    }

    public void setBtnOK(ActionListener listenerReset) {
        btnOK.addActionListener(listenerReset);
    }
}
