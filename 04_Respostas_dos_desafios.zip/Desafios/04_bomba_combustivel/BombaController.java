import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BombaController {
    private BombaView view;
    private BombaModel model;
    private double resultado;

    public BombaController() {
        this.view = new BombaView();
        this.model = new BombaModel();

        view.setBtnOK(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizaView();
            }
        });
    }

    private void atualizaView() {
        model.setTipoCombustivel(view.getTxtTipoCombustivel());
        model.setQtdCombustivel(view.getTxtQtdCombustivel());
        model.setValorLitro(view.getTxtValorLitro());
        model.setValor(view.getTxtValor());
        if (view.getTxtQtdCombustivel() !=0) {
            abastecerPorLitro();
        } else if (view.getTxtValorLitro()!= 0) {
            abastecerPorValor();
        }
    }

    private void abastecerPorValor() {
        resultado = model.getValor()/model.getValorLitro();
        JOptionPane.showMessageDialog(null, "Você abasteceu "+String.format("%.2f", resultado)+" litros de "+model.getTipoCombustivel() );
    }

    private void abastecerPorLitro() {
        resultado = model.getQtdCombustivel()*model.getValorLitro();
        JOptionPane.showMessageDialog(null, "Você pagará R$ "+String.format("%.2f", resultado));
    }

}
