public class BombaModel {
    private String tipoCombustivel;
    private double valorLitro;
    private double valor;
    private double qtdCombustivel;

    public BombaModel() {

    }
    public void setTipoCombustivel(String tipoCombustivel) {
        this.tipoCombustivel = tipoCombustivel;
    }
    public String getTipoCombustivel() {return tipoCombustivel;}
    public void setValorLitro(double valorLitro) {
        this.valorLitro = valorLitro;
    }
    public double getValorLitro() {return valorLitro;}
    public void setValor(double valor) {this.valor = valor; }
    public double getValor () {return valor;}
    public void setQtdCombustivel (double qtdCombustivel) {
        this.qtdCombustivel = qtdCombustivel;
    }
    public double getQtdCombustivel () {return  qtdCombustivel;}
}
