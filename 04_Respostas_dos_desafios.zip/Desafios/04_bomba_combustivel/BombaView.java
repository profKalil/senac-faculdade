import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class BombaView {
    private JLabel lblTipoCombustivel, lblValorLitro, lblValor, lblQtdCombustivel;
    private JTextField txtTipoCombustivel, txtValorLitro, txtValor, txtQtdCombustivel;
    private JButton btnOK;

    public BombaView() {
        JFrame frame = new JFrame("Meu Posto de Gasolina");
        frame.setSize (300, 220);
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        JPanel painel = new JPanel ();
        lblQtdCombustivel = new JLabel("Abastecer por litro: ");
        txtQtdCombustivel = new JTextField(10);
        lblTipoCombustivel = new JLabel("Gasolina, Etanol ou Diesel? ");
        txtTipoCombustivel = new JTextField(20);
        lblValorLitro = new JLabel("Valor do Litro: ");
        txtValorLitro = new JTextField(10);
        lblValor = new JLabel("Abastecer por valor: ");
        txtValor = new JTextField(20);

        btnOK = new JButton("OK");

        painel.add(lblTipoCombustivel);
        painel.add(txtTipoCombustivel);
        painel.add(lblValorLitro);
        painel.add(txtValorLitro);
        painel.add(lblQtdCombustivel);
        painel.add(txtQtdCombustivel);
        painel.add(lblValor);
        painel.add(txtValor);
        painel.add(btnOK);

        frame.add(painel);
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public String getTxtTipoCombustivel() {
        return txtTipoCombustivel.getText();
    }
    public double getTxtQtdCombustivel() {

        if (txtQtdCombustivel.getText().isEmpty()) {
            return 0.0;
        }

        return Double.parseDouble(txtQtdCombustivel.getText());
    }

    public double getTxtValorLitro() {
        return Double.parseDouble(txtValorLitro.getText());
    }

    public double getTxtValor() {

        if (txtValor.getText().isEmpty()) {
            return 0.0;
        }

        return Double.parseDouble(txtValor.getText());
    }
    public void setBtnOK (ActionListener listenerOK) {
        btnOK.addActionListener(listenerOK);
    }
}
