import javax.swing.*;

public class Comentar {
    private String comentou;

    public Comentar () {
        this.comentou = "Comentou!";
    }

    public String getComentou() {
        return comentou;
    }
}
