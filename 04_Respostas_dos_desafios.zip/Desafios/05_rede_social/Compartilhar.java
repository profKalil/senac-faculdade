import javax.swing.*;

public class Compartilhar {
    private String compartilhou;

    public Compartilhar () {
        this.compartilhou = "Compartilhou!";
    }

    public String getCompartilhou() {
        return compartilhou;
    }
}
