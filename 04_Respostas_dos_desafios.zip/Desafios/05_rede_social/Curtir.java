import javax.swing.*;

public class Curtir {
    private String curtiu;

    public Curtir () {
        this.curtiu = "Curtiu!";
    }

    public String getCurtiu() {
        return curtiu;
    }
}
