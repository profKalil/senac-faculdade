import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RedeController {
    private RedeView view;
    private RedeModel model;

    public RedeController() {
        this.view = new RedeView();
        this.model = new RedeModel();

        view.setBtnCurtir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, model.getCurtir().getCurtiu());
            }
        });

        view.setBtnComentar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, model.getComentar().getComentou());
            }
        });

        view.setBtnCompartilhar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, model.getCompartilhar().getCompartilhou());
            }
        });
    }
}
