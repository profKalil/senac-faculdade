public class RedeModel {
    private Curtir curtir;
    private Comentar comentar;
    private Compartilhar compartilhar;

    public RedeModel() {
        this.curtir = new Curtir();
        this.comentar = new Comentar();
        this.compartilhar = new Compartilhar();
    }

    public Curtir getCurtir() {
        return curtir;
    }

    public Comentar getComentar() {
        return comentar;
    }

    public Compartilhar getCompartilhar() {
        return compartilhar;
    }
}
