import javax.swing.*;
import java.awt.event.ActionListener;

public class RedeView {
    private JLabel lblPrincipal;
    private ImageIcon imgCaminho;
    private JLabel lblFoto;

    private JButton btnCurtir;
    private JButton btnComentar;
    private JButton btnCompartilhar;

    public RedeView () {
        JFrame frame = new JFrame("Minha Rede Social");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 330);

        lblPrincipal = new JLabel("Bem-vindo a nossa Rede Social!");
        imgCaminho = new ImageIcon("C:\\Users\\C\\IdeaProjects\\RedeSocial\\src\\imagem_rede_social.jpg");
        lblFoto = new JLabel(imgCaminho);
        btnCurtir = new JButton("Curtir");
        btnComentar = new JButton("Comentar");
        btnCompartilhar = new JButton("Compartilhar");

        JPanel painel = new JPanel();
        painel.add(lblPrincipal);
        painel.add(lblFoto);
        painel.add(btnCurtir);
        painel.add(btnComentar);
        painel.add(btnCompartilhar);

        frame.add(painel);
        frame.setVisible(true);
        frame.setResizable(false);
    }
    public void setBtnCurtir(ActionListener listenerCurtir) {
        btnCurtir.addActionListener(listenerCurtir);
    }
    public void setBtnComentar(ActionListener listenerComentar) {
        btnComentar.addActionListener(listenerComentar);
    }
    public void setBtnCompartilhar(ActionListener listenerCompartilhar) {
        btnCompartilhar.addActionListener(listenerCompartilhar);
    }
}
